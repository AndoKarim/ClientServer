package data.exceptions;

/**
 * @author Loris Friedel
 */
public class MalformedIdeaException extends RuntimeException {
  public MalformedIdeaException(String msg) {
    super(msg);
  }
}
