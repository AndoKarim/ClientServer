package client.flag;

/**
 * @author Loris Friedel
 */
public enum Receive {
  OK, ERROR
}
