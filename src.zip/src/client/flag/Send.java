package client.flag;

/**
 * @author Loris Friedel
 */
public enum Send {
  ADD_IDEA, GET_LIST_IDEAS, REGISTER_IN_IDEA, GET_REGISTERED_IN
}
