package client;

import data.Idea;
import data.Packet;
import javafx.util.Pair;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.List;

import static client.flag.Send.ADD_IDEA;
import static client.flag.Send.GET_LIST_IDEAS;

/**
 * A client which send and get ideas.
 *
 * @author Anthony LOROSCIO
 */
public class ClientV2 {

  private final String host;
  private final int port;

  public ClientV2(String host, int port) {
    this.host = host;
    this.port = port;
  }

  /**
   * Request the server to add the given idea into the database.
   *
   * @param idea     Idea to be added in the database.

   */
  public String sendIdea(Idea idea) throws IOException {
    Packet packet = new Packet(ADD_IDEA, idea);
    return transaction(packet).getKey();
  }

  /**
   * Request the server to send to the client all stored ideas.
   *
   */
  public Pair<String, List<Idea>> getIdeas() throws IOException {
    Packet packet = new Packet(GET_LIST_IDEAS);
    return (Pair) transaction(packet);
  }

  /**
   * Transaction to the server.
   *
   * @param packet   Packet to be sent to the server.
   */
  private Pair<String, Object> transaction(Packet packet) throws IOException {
    return executeTransaction(packet);
  }

  /**
   * Execute a transaction, sending the given packet to the server,
   * waiting for its response to call the given consumer.
   *
   * @param packet   Packet to be sent to the server.
   */
  private Pair<String, Object> executeTransaction(Packet packet) throws IOException {
    try (Socket socket = new Socket(host, port);
         ObjectOutputStream output = new ObjectOutputStream(socket.getOutputStream());
         ObjectInputStream input = new ObjectInputStream(socket.getInputStream())) {

      // Send packet to the server
      System.out.println("Sending " + packet.getQualifier());
      output.writeObject(packet);

      // Get the response
      Packet response = (Packet) input.readObject();
      System.out.println("Received " + response.getQualifier());

      socket.close();

      // Process the response
      return new Pair<>(response.getQualifier(), response.getValue());
    } catch ( ClassNotFoundException | IOException e) {
      System.out.println("error" + e);
      throw new IOException();
    }
  }
}
